CREATE VIEW View_s 
AS 
SELECT *
FROM student 
where sno in
(
	SELECT sno 
	FROM cs 
	WHERE cno='001' AND sno in
	(
		SELECT sno 
		FROM cs 
		WHERE cno='002'
	)
);
go

