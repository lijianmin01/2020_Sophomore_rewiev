CREATE VIEW View_s_1
AS
SELECT student.*,cno
FROM student,cs
Where student.sno=cs.sno;
go

