
CREATE FUNCTION student_course(@sno CHAR(6))
RETURNS TABLE
AS
RETURN
	SELECT Student.Sno,Student.Sname,Course.Cname,Score.Degree 
	FROM (Score LEFT OUTER JOIN Student ON Score.Sno=Student.Sno) 
    LEFT OUTER JOIN Course 
    ON Score.Cno=Course.Cno 
    WHERE @sno=Student.Sno
go

