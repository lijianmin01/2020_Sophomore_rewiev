create proc proc_class_avggrade
@class char(6),
@cno char(6),
@savg int output
as
begin
	select @savg=avg(degree)
	from score
	where cno=@cno and sno in
		(
			select sno
			from student 
			where student.class=@class
		)
end
go

