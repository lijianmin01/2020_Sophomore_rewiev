create trigger tr_insert_sc
on sc
after insert
as
begin
    declare @sno char(9)
    select @sno=sno from inserted
    if not exists(select * from student where sno=@sno)
        delete from sc where sno=@sno
end
go

