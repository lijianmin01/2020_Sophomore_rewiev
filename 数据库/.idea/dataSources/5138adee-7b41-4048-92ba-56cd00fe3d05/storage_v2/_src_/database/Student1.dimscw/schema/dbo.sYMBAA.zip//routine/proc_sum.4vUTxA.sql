create proc proc_sum
@sdept_cnt char(10),
@student_sum int out
as
begin
    select count(*)
    from Student
    where Sdept=@sdept_cnt
end
go

