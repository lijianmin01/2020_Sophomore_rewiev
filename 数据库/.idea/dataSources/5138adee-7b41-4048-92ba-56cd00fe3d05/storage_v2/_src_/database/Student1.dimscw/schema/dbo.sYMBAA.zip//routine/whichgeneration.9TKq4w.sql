create function whichgeneration(@birthday datetime)
returns varchar(12)
as
begin
    if year(@birthday) < 1980
        return 'Too Old !'
    else if year(@birthday) < 1990
        return '80s'
    else
        return '90s'
    return 0
end
go

