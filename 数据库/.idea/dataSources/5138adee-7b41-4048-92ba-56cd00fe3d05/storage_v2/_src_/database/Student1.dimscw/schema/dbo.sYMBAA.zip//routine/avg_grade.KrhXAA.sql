create function avg_grade(@sdept varchar(10))
returns table
as
    return select sc.sno,avg(grade) '成绩'
    from Student left join sc on Student.sno=sc.sno
    where Student.Sdept=@sdept
    group by sc.sno
go

