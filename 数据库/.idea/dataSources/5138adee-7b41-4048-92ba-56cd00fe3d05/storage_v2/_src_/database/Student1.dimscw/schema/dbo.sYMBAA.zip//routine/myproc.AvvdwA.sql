create proc  myproc
as
begin
select *
from student
where sno in (
        select sno
        from sc
        where grade<60
        group by sno
        having count(*)>=1
    )
end
go

