create function fun1()
returns table
as
    return select sno,sname from Student
go

