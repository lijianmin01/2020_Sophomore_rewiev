create proc proc_insert_student
@sno char(9),
@sname char(10),
@ssex char(2)='男',
@sage int,
@sdept varchar(20)
as
begin
    insert into Student(sno, sname, ssex, sage, sdept)
    values (@sno,@sname,@ssex,@sage,@sdept)
end
go

