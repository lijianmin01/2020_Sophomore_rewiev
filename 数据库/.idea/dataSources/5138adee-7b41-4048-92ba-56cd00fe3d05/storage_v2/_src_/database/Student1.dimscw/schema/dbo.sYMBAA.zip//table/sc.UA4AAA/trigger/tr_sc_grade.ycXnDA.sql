create trigger tr_sc_grade
on sc
after insert,update
as
begin
    declare @grade int
    select @grade=grade from inserted
    if(@grade<0 or @grade>100)
        begin
            --提示
            raiserror('成绩必须在0到100之间',16,10)
            -- 万能钥匙，之前所有操作不算数
            rollback transaction
        end
end
go

