create function dateonly (@date datetime)
returns varchar(12)
as
begin
    return convert(varchar(12),@date,101)
end
go

