create proc savggrade
@sno char(9),
--输出型的形式参数
@savg int output
as
begin
    select avg(grade)
    from sc
    where sno = @sno
end
go

