 create procedure sp_DTA_query_cost_helper_relational
			@SessionID		int
			as
			begin 	select "语句 ID" = QueryID, "语句字符串" = StatementString, "提高百分比" = 	
					CASE
						WHEN CurrentCost = 0 THEN 0.00
						WHEN CurrentCost <> 0 THEN
						CAST((100.0*(CurrentCost - RecommendedCost)/CurrentCost) as decimal (20,2))
					end , "语句类型" = CASE 
							WHEN StatementType = 0 THEN 'Select'
							WHEN StatementType = 1 THEN 'Update'
							WHEN StatementType = 2 THEN 'Insert'
							WHEN StatementType = 3 THEN 'Delete'
							WHEN StatementType = 4 THEN 'Merge'
							end 	from [msdb].[dbo].[DTA_reports_query]
					where SessionID=@SessionID
					order by "提高百分比" desc  end
 go

