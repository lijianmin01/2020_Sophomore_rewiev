	create procedure sp_DTA_wkld_analysis_helper_relational
						@SessionID		int
						as
						begin	select "语句类型" = CASE 
						WHEN StatementType = 0 THEN 'Select'
						WHEN StatementType = 1 THEN 'Update'
						WHEN StatementType = 2 THEN 'Insert'
						WHEN StatementType = 3 THEN 'Delete'
						WHEN StatementType = 4 THEN 'Merge'
						end, "语句数" =COUNT(QueryID), "开销降低" =SUM(CASE
															WHEN RecommendedCost<CurrentCost THEN 1 else 0 end), "开销增加" =SUM(CASE
						WHEN RecommendedCost>CurrentCost THEN 1 else 0 end), "未更改" =SUM(CASE
						WHEN RecommendedCost=CurrentCost THEN 1 else 0 end) 	from 
						[msdb].[dbo].[DTA_reports_query]
						where 
						SessionID=@SessionID group by StatementType  end
    go

