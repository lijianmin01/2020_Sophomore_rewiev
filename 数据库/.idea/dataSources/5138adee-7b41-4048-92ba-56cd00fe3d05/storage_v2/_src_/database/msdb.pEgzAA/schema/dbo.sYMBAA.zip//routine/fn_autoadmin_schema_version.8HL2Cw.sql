
CREATE FUNCTION fn_autoadmin_schema_version() 
RETURNS INT 
AS 
BEGIN 
    RETURN 0
END
go

