create procedure sp_DTA_index_usage_helper_relational
	@SessionID		int,
	@IsRecommended	int
	as begin select D1.DatabaseName as "数据库名称" ,T1.SchemaName as "架构名称" ,T1.TableName as "表/视图名称" ,I1.IndexName as "索引名称" ,R.Count as "引用数" ,CAST(R.Usage as decimal(38,2)) as "使用百分比" from 
				DTA_reports_database as D1 ,
				DTA_reports_index as I1,
				DTA_reports_table as T1,
				(
					select D.DatabaseID,T.TableID ,
							I.IndexID  ,SUM(Q.Weight) as Count,
							100.0 *  SUM(Q.Weight) / 
							( 1.0 * (	select	CASE WHEN SUM(Q.Weight) > 0 THEN  SUM(Q.Weight)
												else 1
												end	
									
										from [msdb].[dbo].[DTA_reports_query] as Q
										where Q.SessionID = @SessionID ))
				as Usage
		from 
				[msdb].[dbo].[DTA_reports_index] as I	
				LEFT OUTER JOIN
				[msdb].[dbo].[DTA_reports_queryindex] as QI ON QI.IndexID = I.IndexID
				LEFT OUTER JOIN
				[msdb].[dbo].[DTA_reports_query] as Q ON QI.QueryID = Q.QueryID
				JOIN
				[msdb].[dbo].[DTA_reports_table] as T ON I.TableID = T.TableID
				JOIN
				[msdb].[dbo].[DTA_reports_database] as D ON T.DatabaseID = D.DatabaseID
				and Q.SessionID = QI.SessionID and 
				QI.IsRecommendedConfiguration = @IsRecommended and
				Q.SessionID = @SessionID
				
				GROUP BY I.IndexID,T.TableID,D.DatabaseID) as R
				where R.DatabaseID = D1.DatabaseID and
				R.TableID = T1.TableID and
				R.IndexID = I1.IndexID and
				D1.SessionID = @SessionID  and
				R.Count > 0
				order by R.Count desc end
go

