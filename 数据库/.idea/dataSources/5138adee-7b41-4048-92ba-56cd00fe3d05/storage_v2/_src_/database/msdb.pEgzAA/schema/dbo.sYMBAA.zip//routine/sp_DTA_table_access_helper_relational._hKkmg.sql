 create procedure sp_DTA_table_access_helper_relational
			@SessionID		int
			as
			begin select D1.DatabaseName as "数据库名称" ,T1.SchemaName as "架构名称" ,T1.TableName as "表名" ,R.Count as "引用数" ,CAST(R.Usage as decimal(38,2)) as "使用百分比" from 
				[msdb].[dbo].[DTA_reports_database] as D1 ,
				[msdb].[dbo].[DTA_reports_table] as T1,
				(
					select D.DatabaseID,T.TableID 
							,SUM(Q.Weight) as Count,
							100.0 *  SUM(Q.Weight) / 
							( 1.0 * (	select	CASE WHEN SUM(Q.Weight) > 0 THEN  SUM(Q.Weight)
												else 1
												end	
									
										from [msdb].[dbo].[DTA_reports_query] as Q
										where Q.SessionID = @SessionID ))
				as Usage
		from 
				[msdb].[dbo].[DTA_reports_table] as T
				LEFT OUTER JOIN
				[msdb].[dbo].[DTA_reports_querytable] as QT ON QT.TableID = T.TableID
				LEFT OUTER JOIN
				[msdb].[dbo].[DTA_reports_query] as Q ON QT.QueryID = Q.QueryID
				JOIN
				DTA_reports_database as D ON T.DatabaseID = D.DatabaseID
				and Q.SessionID = QT.SessionID and 
				Q.SessionID = @SessionID		
				GROUP BY T.TableID,D.DatabaseID) as R
				where R.DatabaseID = D1.DatabaseID and
				R.TableID = T1.TableID and
				D1.SessionID = @SessionID and
				R.Count > 0
				order by R.Count desc  end
 go

